package com.example.webbanhang;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class banhangcontroller {
	
	@Autowired
	private webbanhangDAO dao;

	@RequestMapping("/")
	public String index() {
		return "index";
		
	}
	
	
	@RequestMapping("/login")
	public String login() {
		return "login";
	}
	
	@RequestMapping("/registerUser")
	public String NewForm(Model model) {
		model.addAttribute("register", new register());
		
		return "newUser";
	}

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public String save(@ModelAttribute ("register") register register) {
		dao.register(register);
		return "redirect:/";
	}




}
